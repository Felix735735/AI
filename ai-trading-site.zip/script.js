ScrollReveal().reveal('.section', {
  duration: 800,
  distance: '40px',
  origin: 'bottom',
  easing: 'ease-in-out',
  interval: 200
});